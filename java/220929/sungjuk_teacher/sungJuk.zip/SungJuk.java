package sungJuk;

import java.util.ArrayList;

public interface SungJuk {
	public void execute(ArrayList<SungJukDTO> list);
}
